import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";
import type { DashboardResponse, Product } from "../lib/types";
import { StatCard } from "../components/StatCard";
import { ProductTable } from "../components/ProductTable";
import { Link } from "wouter";
import { formatDateTime } from "../lib/format";

export function DashboardPage() {
  const [dashboard, setDashboard] = useState<DashboardResponse | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.getDashboard(), api.getProducts()])
      .then(([dashboardData, productData]) => {
        setDashboard(dashboardData);
        setProducts(productData);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const filteredProducts = useMemo(() => {
    const keyword = search.trim().toLowerCase();
    if (!keyword) return products;
    return products.filter(product =>
      [product.name, product.partNumber, product.toolType, product.supplier]
        .filter(Boolean)
        .some(text => String(text).toLowerCase().includes(keyword)),
    );
  }, [products, search]);

  if (loading) {
    return <div className="empty-state">讀取中...</div>;
  }

  if (error) {
    return <div className="empty-state error">{error}</div>;
  }

  return (
    <div className="page-stack">
      <section className="hero-card">
        <div>
          <p className="eyebrow">M7 Product History</p>
          <h2>把產品履歷主流程，重新做成你能長期掌控的網站</h2>
          <p className="hero-copy">
            這版先把首頁列表、產品詳情、匯入頁、報表頁整理乾淨，不再被原本混雜的路由和上傳流程綁住。
          </p>
        </div>
        <div className="hero-actions">
          <Link href="/products/new" className="primary-button">
            新增品項
          </Link>
          <Link href="/reports" className="secondary-button">
            查看報表
          </Link>
        </div>
      </section>

      <section className="stats-grid">
        <StatCard label="品項數量" value={dashboard?.totalProducts ?? 0} hint="目前資料檔中的產品總數" />
        <StatCard label="測試紀錄" value={dashboard?.totalRecords ?? 0} hint="所有產品累積測試筆數" />
        <StatCard label="待確認" value={dashboard?.pendingRecords ?? 0} hint="需要回頭檢查的測試結果" />
      </section>

      <section className="panel">
        <div className="panel-head responsive-row">
          <div>
            <h2>查找品項</h2>
            <p>可以先用產品名稱、料號、Tool Type 查詢</p>
          </div>
          <input
            className="search-input"
            placeholder="搜尋產品名稱 / 料號 / Tool Type"
            value={search}
            onChange={event => setSearch(event.target.value)}
          />
        </div>
      </section>

      <ProductTable products={filteredProducts} />

      <section className="panel latest-panel">
        <div className="panel-head">
          <div>
            <h2>最近測試紀錄</h2>
            <p>快速查看最新異動</p>
          </div>
        </div>
        <div className="timeline-list">
          {dashboard?.latestTests.map(item => (
            <div key={`${item.productId}-${item.id}`} className="timeline-item">
              <div className="timeline-date">{formatDateTime(item.testDate)}</div>
              <div>
                <strong>
                  {item.productName} / {item.metricName}
                </strong>
                <p>
                  {item.value} {item.unit} ・ {item.status}
                </p>
              </div>
              <Link href={`/products/${item.productId}`} className="text-link">
                進入履歷
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
