import { Route, Switch } from "wouter";
import { Layout } from "./components/Layout";
import { DashboardPage } from "./pages/DashboardPage";
import { ProductFormPage } from "./pages/ProductFormPage";
import { ProductDetailPage } from "./pages/ProductDetailPage";
import { ImportPage } from "./pages/ImportPage";
import { ReportsPage } from "./pages/ReportsPage";

export default function App() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={DashboardPage} />
        <Route path="/products/new" component={ProductFormPage} />
        <Route path="/products/:id/edit" component={ProductFormPage} />
        <Route path="/products/:id/import" component={ImportPage} />
        <Route path="/products/:id" component={ProductDetailPage} />
        <Route path="/reports" component={ReportsPage} />
        <Route>
          <div className="empty-state error">找不到頁面</div>
        </Route>
      </Switch>
    </Layout>
  );
}
