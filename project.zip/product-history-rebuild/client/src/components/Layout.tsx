import { Link, useLocation } from "wouter";
import type { PropsWithChildren } from "react";

const navItems = [
  { href: "/", label: "儀表板" },
  { href: "/products/new", label: "新增品項" },
  { href: "/reports", label: "報表" },
];

export function Layout({ children }: PropsWithChildren) {
  const [location] = useLocation();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand-badge">M7</div>
          <div>
            <h1>產品履歷網站</h1>
            <p>重構版基底</p>
          </div>
        </div>
        <nav className="nav-list">
          {navItems.map(item => (
            <Link key={item.href} href={item.href} className={location === item.href ? "nav-link active" : "nav-link"}>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="sidebar-note">
          <strong>這版的目標</strong>
          <p>把匯入、履歷、報表三條主流程變乾淨，之後版本才好控。</p>
        </div>
      </aside>
      <main className="page-container">{children}</main>
    </div>
  );
}
