import { ChangeEvent, useMemo, useState } from "react";
import { api } from "../lib/api";
import type { ParsedImportRecord } from "../lib/types";
import { useLocation, useRoute } from "wouter";
import { formatDateTime } from "../lib/format";

async function fileToBase64(file: File) {
  const buffer = await file.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;

  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }

  return btoa(binary);
}

export function ImportPage() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/products/:id/import");
  const productId = useMemo(() => (match ? Number(params?.id) : null), [match, params]);
  const [fileName, setFileName] = useState("");
  const [rows, setRows] = useState<ParsedImportRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError("");
    setMessage("");

    try {
      const base64 = await fileToBase64(file);
      const result = await api.previewImport(file.name, base64);
      setFileName(result.fileName);
      setRows(result.rows);
      setMessage(`已解析 ${result.rowCount} 筆資料，已辨識 ${result.detectedMetrics.length} 個測試項目。`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "解析失敗");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  async function handleCommit() {
    if (!productId || rows.length === 0) return;
    setLoading(true);
    setError("");
    setMessage("");
    try {
      const result = await api.commitImport(productId, fileName, rows);
      setMessage(`匯入完成：成功 ${result.inserted} 筆，忽略 ${result.ignored} 筆。`);
      setTimeout(() => navigate(`/products/${productId}`), 900);
    } catch (err) {
      setError(err instanceof Error ? err.message : "寫入失敗");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page-stack">
      <section className="page-header">
        <div>
          <p className="eyebrow">Import Center</p>
          <h2>匯入測試資料</h2>
          <p>這版把上傳流程拆成兩步：先解析預覽，再寫入資料。</p>
        </div>
      </section>

      <section className="panel upload-panel">
        <div className="upload-box">
          <strong>支援格式：CSV / XLSX / DOCX</strong>
          <p>建議檔案內至少要有「測試名稱」與「測試內容」兩個欄位。</p>
          <input type="file" accept=".csv,.xlsx,.xls,.docx" onChange={handleFileChange} />
        </div>

        {loading ? <div className="inline-note">處理中...</div> : null}
        {message ? <div className="inline-success">{message}</div> : null}
        {error ? <div className="inline-error">{error}</div> : null}
      </section>

      <section className="panel">
        <div className="panel-head responsive-row">
          <div>
            <h3>解析預覽</h3>
            <p>確認欄位無誤後，再按「確認匯入」</p>
          </div>
          <button className="primary-button" onClick={handleCommit} disabled={rows.length === 0 || loading}>
            確認匯入
          </button>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>測試日期</th>
                <th>測試名稱</th>
                <th>測試內容</th>
                <th>單位</th>
                <th>狀態</th>
                <th>備註</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="muted center-cell">
                    尚未解析任何資料
                  </td>
                </tr>
              ) : (
                rows.map((row, index) => (
                  <tr key={`${row.metricName}-${index}`}>
                    <td>{index + 1}</td>
                    <td>{row.testDate ? formatDateTime(row.testDate) : "-"}</td>
                    <td>{row.metricName}</td>
                    <td>{row.value}</td>
                    <td>{row.unit || "-"}</td>
                    <td>{row.status || "pending"}</td>
                    <td>{row.remarks || "-"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
