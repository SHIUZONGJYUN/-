import mammoth from "mammoth";
import * as XLSX from "xlsx";
import type { ParsedImportRecord, RecordStatus } from "./types";

function normalizeHeader(header: string) {
  return header.replace(/\s+/g, "").toLowerCase();
}

function pickField(record: Record<string, unknown>, candidates: string[]) {
  const normalizedEntries = Object.entries(record).map(([key, value]) => [normalizeHeader(key), value] as const);
  for (const candidate of candidates) {
    const found = normalizedEntries.find(([key]) => key === normalizeHeader(candidate));
    if (found) {
      return found[1];
    }
  }
  return undefined;
}

function normalizeStatus(value: unknown): RecordStatus | undefined {
  const text = String(value ?? "").trim().toLowerCase();
  if (!text) return undefined;
  if (["pass", "ok", "合格", "通過"].includes(text)) return "pass";
  if (["fail", "ng", "不合格", "失敗"].includes(text)) return "fail";
  if (["pending", "待定", "待確認"].includes(text)) return "pending";
  return undefined;
}

function normalizeDate(value: unknown) {
  if (!value) return undefined;
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) {
      return new Date(parsed.y, parsed.m - 1, parsed.d, parsed.H, parsed.M, parsed.S).toISOString();
    }
  }
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? undefined : date.toISOString();
}

function mapRows(rows: Array<Record<string, unknown>>): ParsedImportRecord[] {
  return rows
    .map(row => ({
      metricName: String(
        pickField(row, ["測試名稱", "metricName", "metric", "testName", "項目", "測試項目"]) ?? "",
      ).trim(),
      value: String(
        pickField(row, ["測試內容", "value", "result", "測試結果", "數值"]) ?? "",
      ).trim(),
      unit: String(pickField(row, ["單位", "unit"]) ?? "").trim() || undefined,
      testDate: normalizeDate(pickField(row, ["測試日期", "testDate", "date"])) ,
      status: normalizeStatus(pickField(row, ["狀態", "status"])),
      remarks: String(pickField(row, ["備註", "remarks", "note"]) ?? "").trim() || undefined,
      testedBy: String(pickField(row, ["測試人員", "testedBy", "operator"]) ?? "").trim() || undefined,
      testCondition: String(pickField(row, ["測試條件", "condition", "testCondition"]) ?? "").trim() || undefined,
      batchNumber: String(pickField(row, ["批號", "batch", "batchNumber"]) ?? "").trim() || undefined,
    }))
    .filter(item => item.metricName || item.value);
}

function parseCsv(text: string): ParsedImportRecord[] {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(header => header.trim());
  const rows = lines.slice(1).map(line => {
    const cells = line.split(",");
    return headers.reduce<Record<string, unknown>>((acc, header, index) => {
      acc[header] = cells[index]?.trim() ?? "";
      return acc;
    }, {});
  });
  return mapRows(rows);
}

function parseXlsx(buffer: Buffer): ParsedImportRecord[] {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const firstSheetName = workbook.SheetNames[0];
  const firstSheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: "" });
  return mapRows(rows);
}

async function parseDocx(buffer: Buffer): Promise<ParsedImportRecord[]> {
  const result = await mammoth.extractRawText({ buffer });
  const lines = result.value
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);

  const items: ParsedImportRecord[] = [];

  for (const line of lines) {
    const parts = line.split(/[\t|,，]/).map(item => item.trim()).filter(Boolean);
    if (parts.length >= 2) {
      items.push({
        metricName: parts[0],
        value: parts[1],
        unit: parts[2],
        remarks: parts.slice(3).join(" ") || undefined,
      });
    }
  }

  return items;
}

export async function parseImportFile(fileName: string, base64: string) {
  const buffer = Buffer.from(base64, "base64");
  const extension = fileName.toLowerCase().split(".").pop();

  if (extension === "csv") {
    return parseCsv(buffer.toString("utf-8"));
  }
  if (extension === "xlsx" || extension === "xls") {
    return parseXlsx(buffer);
  }
  if (extension === "docx") {
    return parseDocx(buffer);
  }

  throw new Error("目前只支援 CSV / XLSX / DOCX");
}
