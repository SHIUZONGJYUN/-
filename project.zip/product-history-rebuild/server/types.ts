export type ProductCategory = "electric" | "pneumatic";
export type RecordStatus = "pass" | "fail" | "pending";

export interface Metric {
  id: number;
  name: string;
  unit: string;
  displayOrder: number;
}

export interface TestRecord {
  id: number;
  metricId: number;
  metricName: string;
  value: string;
  unit: string;
  status: RecordStatus;
  testDate: string;
  remarks?: string;
  testedBy?: string;
  testCondition?: string;
  batchNumber?: string;
}

export interface ImportLog {
  id: number;
  fileName: string;
  createdAt: string;
  successCount: number;
  failureCount: number;
  status: "success" | "partial" | "failed";
  errorMessage?: string;
}

export interface Product {
  id: number;
  name: string;
  partNumber: string;
  supplier?: string;
  category: ProductCategory;
  toolType?: string;
  description?: string;
  features: string[];
  createdAt: string;
  updatedAt: string;
  metrics: Metric[];
  records: TestRecord[];
  imports: ImportLog[];
}

export interface AppData {
  products: Product[];
}

export interface ParsedImportRecord {
  metricName: string;
  value: string;
  unit?: string;
  testDate?: string;
  status?: RecordStatus;
  remarks?: string;
  testedBy?: string;
  testCondition?: string;
  batchNumber?: string;
}
