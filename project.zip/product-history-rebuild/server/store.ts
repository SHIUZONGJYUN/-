import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { AppData, Metric, ParsedImportRecord, Product, TestRecord } from "./types";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataFile = path.resolve(__dirname, "../data/app-data.json");

function readRaw(): AppData {
  const text = fs.readFileSync(dataFile, "utf-8");
  return JSON.parse(text) as AppData;
}

function writeRaw(data: AppData) {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2), "utf-8");
}

function nextId(items: Array<{ id: number }>) {
  return items.length === 0 ? 1 : Math.max(...items.map(item => item.id)) + 1;
}

export function getAllProducts() {
  const data = readRaw();
  return data.products.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function getProductById(id: number) {
  return getAllProducts().find(product => product.id === id) ?? null;
}

export function createProduct(input: Omit<Product, "id" | "createdAt" | "updatedAt" | "metrics" | "records" | "imports"> & { metrics?: Metric[] }) {
  const data = readRaw();
  const now = new Date().toISOString();
  const product: Product = {
    id: nextId(data.products),
    name: input.name,
    partNumber: input.partNumber,
    supplier: input.supplier,
    category: input.category,
    toolType: input.toolType,
    description: input.description,
    features: input.features,
    createdAt: now,
    updatedAt: now,
    metrics: input.metrics ?? [],
    records: [],
    imports: [],
  };
  data.products.push(product);
  writeRaw(data);
  return product;
}

export function updateProduct(id: number, input: Partial<Omit<Product, "id" | "metrics" | "records" | "imports" | "createdAt" | "updatedAt">>) {
  const data = readRaw();
  const product = data.products.find(item => item.id === id);
  if (!product) {
    return null;
  }
  Object.assign(product, input, { updatedAt: new Date().toISOString() });
  writeRaw(data);
  return product;
}

export function dashboardSummary() {
  const products = getAllProducts();
  const totalProducts = products.length;
  const totalRecords = products.reduce((sum, product) => sum + product.records.length, 0);
  const pendingRecords = products.reduce(
    (sum, product) => sum + product.records.filter(record => record.status === "pending").length,
    0,
  );
  const latestTests = products
    .flatMap(product =>
      product.records.map(record => ({
        productId: product.id,
        productName: product.name,
        partNumber: product.partNumber,
        ...record,
      })),
    )
    .sort((a, b) => b.testDate.localeCompare(a.testDate))
    .slice(0, 8);

  return {
    totalProducts,
    totalRecords,
    pendingRecords,
    latestTests,
  };
}

function ensureMetric(product: Product, metricName: string, unit?: string) {
  const existing = product.metrics.find(metric => metric.name === metricName);
  if (existing) {
    if (!existing.unit && unit) {
      existing.unit = unit;
    }
    return existing;
  }
  const metric: Metric = {
    id: nextId(product.metrics),
    name: metricName,
    unit: unit || "-",
    displayOrder: product.metrics.length + 1,
  };
  product.metrics.push(metric);
  return metric;
}

export function commitImport(productId: number, fileName: string, rows: ParsedImportRecord[]) {
  const data = readRaw();
  const product = data.products.find(item => item.id === productId);
  if (!product) {
    throw new Error("找不到產品");
  }

  let inserted = 0;
  const now = new Date().toISOString();

  for (const row of rows) {
    if (!row.metricName || row.value === undefined || row.value === null || row.value === "") {
      continue;
    }

    const metric = ensureMetric(product, row.metricName, row.unit);
    const record: TestRecord = {
      id: nextId(product.records),
      metricId: metric.id,
      metricName: row.metricName,
      value: String(row.value),
      unit: row.unit || metric.unit || "-",
      status: row.status || "pending",
      testDate: row.testDate || now,
      remarks: row.remarks,
      testedBy: row.testedBy,
      testCondition: row.testCondition,
      batchNumber: row.batchNumber,
    };
    product.records.push(record);
    inserted += 1;
  }

  product.updatedAt = now;
  product.imports.unshift({
    id: nextId(product.imports),
    fileName,
    createdAt: now,
    successCount: inserted,
    failureCount: rows.length - inserted,
    status: inserted > 0 ? (inserted === rows.length ? "success" : "partial") : "failed",
  });

  writeRaw(data);

  return {
    inserted,
    ignored: rows.length - inserted,
  };
}
