import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";
import type { Product } from "../lib/types";
import { formatDate } from "../lib/format";

function buildMetricSeries(product: Product) {
  const grouped = new Map<string, number[]>();
  product.records.forEach(record => {
    const numeric = Number(record.value);
    if (!Number.isNaN(numeric)) {
      const current = grouped.get(record.metricName) || [];
      current.push(numeric);
      grouped.set(record.metricName, current);
    }
  });
  return Array.from(grouped.entries()).map(([metricName, values]) => ({
    metricName,
    avg: values.reduce((sum, value) => sum + value, 0) / values.length,
    max: Math.max(...values),
    min: Math.min(...values),
  }));
}

export function ReportsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .getProducts()
      .then(data => {
        setProducts(data);
        setSelectedId(data[0]?.id ?? null);
      })
      .catch(err => setError(err.message));
  }, []);

  const selectedProduct = useMemo(
    () => products.find(product => product.id === selectedId) || null,
    [products, selectedId],
  );
  const series = selectedProduct ? buildMetricSeries(selectedProduct) : [];

  if (error) {
    return <div className="empty-state error">{error}</div>;
  }

  return (
    <div className="page-stack">
      <section className="page-header">
        <div>
          <p className="eyebrow">Reports</p>
          <h2>產品履歷報表總覽</h2>
          <p>這版報表先專注在你實際需要的內容：末測日期、測試項目、數值統計。</p>
        </div>
      </section>

      <section className="panel responsive-row">
        <div>
          <h3>選擇產品</h3>
          <p>先聚焦單一產品，把履歷摘要看清楚。</p>
        </div>
        <select
          className="filter-select"
          value={selectedId ?? ""}
          onChange={event => setSelectedId(Number(event.target.value))}
        >
          {products.map(product => (
            <option key={product.id} value={product.id}>
              {product.name} / {product.partNumber}
            </option>
          ))}
        </select>
      </section>

      {selectedProduct ? (
        <>
          <section className="stats-grid three-columns">
            <article className="stat-card">
              <p className="stat-label">產品</p>
              <strong className="stat-value">{selectedProduct.name}</strong>
              <p className="stat-hint">{selectedProduct.partNumber}</p>
            </article>
            <article className="stat-card">
              <p className="stat-label">末測日期</p>
              <strong className="stat-value">
                {selectedProduct.records[0] ? formatDate(selectedProduct.records[0].testDate) : "尚未測試"}
              </strong>
              <p className="stat-hint">已移除合格率卡片</p>
            </article>
            <article className="stat-card">
              <p className="stat-label">測試筆數</p>
              <strong className="stat-value">{selectedProduct.records.length}</strong>
              <p className="stat-hint">總紀錄數</p>
            </article>
          </section>

          <section className="panel">
            <div className="panel-head">
              <div>
                <h3>各測試項目摘要</h3>
                <p>平均值、最大值、最小值</p>
              </div>
            </div>
            <div className="metric-grid">
              {series.map(item => (
                <article key={item.metricName} className="metric-card">
                  <div className="metric-card-head">
                    <strong>{item.metricName}</strong>
                  </div>
                  <div className="report-values">
                    <div><span>平均</span><strong>{item.avg.toFixed(2)}</strong></div>
                    <div><span>最大</span><strong>{item.max.toFixed(2)}</strong></div>
                    <div><span>最小</span><strong>{item.min.toFixed(2)}</strong></div>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </>
      ) : (
        <div className="empty-state">尚無可顯示產品</div>
      )}
    </div>
  );
}
