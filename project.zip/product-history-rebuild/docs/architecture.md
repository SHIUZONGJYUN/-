# 重構架構說明

## 核心原則

- 把資料流切清楚
- 把畫面和資料操作分離
- 把匯入解析集中到後端
- 把未來可替換的地方封裝起來

## 資料結構

- Product
- Metric
- TestRecord
- ImportJob

## 可替換層

### 目前
- `server/store.ts`：JSON 檔案

### 未來可換成
- MySQL / TiDB / PostgreSQL
- ORM：Drizzle / Prisma

## 匯入流程

1. 前端讀檔後轉為 base64
2. 傳給 `/api/import/preview`
3. 後端依副檔名解析成統一資料格式
4. 前端顯示預覽
5. 使用者按確認後呼叫 `/api/import/commit`
6. 後端建立缺少的 metric 並寫入 test record
