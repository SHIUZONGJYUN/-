import { useEffect, useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { api } from "../lib/api";
import type { Product } from "../lib/types";
import { formatDate, formatDateTime } from "../lib/format";

export function ProductDetailPage() {
  const [match, params] = useRoute("/products/:id");
  const productId = useMemo(() => (match ? Number(params?.id) : null), [match, params]);
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!productId) return;
    api
      .getProduct(productId)
      .then(setProduct)
      .catch(err => setError(err.message));
  }, [productId]);

  if (error) {
    return <div className="empty-state error">{error}</div>;
  }

  if (!product) {
    return <div className="empty-state">讀取履歷中...</div>;
  }

  const sortedRecords = [...product.records].sort((a, b) => b.testDate.localeCompare(a.testDate));
  const latest = sortedRecords[0];
  const groupedByMetric = product.metrics.map(metric => ({
    ...metric,
    records: sortedRecords.filter(record => record.metricId === metric.id).slice(0, 5),
  }));

  return (
    <div className="page-stack">
      <section className="page-header split-header">
        <div>
          <p className="eyebrow">Product History</p>
          <h2>
            {product.name} <span className="muted">{product.partNumber}</span>
          </h2>
          <p>{product.description || "尚未填寫描述"}</p>
        </div>
        <div className="header-actions">
          <Link href={`/products/${product.id}/edit`} className="secondary-button">
            編輯品項
          </Link>
          <Link href={`/products/${product.id}/import`} className="primary-button">
            匯入測試資料
          </Link>
        </div>
      </section>

      <section className="stats-grid two-columns">
        <article className="panel">
          <h3>基本資料</h3>
          <div className="detail-grid">
            <div><span>供應商</span><strong>{product.supplier || "-"}</strong></div>
            <div><span>類別</span><strong>{product.category === "electric" ? "電動" : "氣動"}</strong></div>
            <div><span>Tool Type</span><strong>{product.toolType || "-"}</strong></div>
            <div><span>建立時間</span><strong>{formatDate(product.createdAt)}</strong></div>
            <div><span>末測日期</span><strong>{latest ? formatDateTime(latest.testDate) : "尚未測試"}</strong></div>
            <div><span>測試筆數</span><strong>{product.records.length}</strong></div>
          </div>
          <div className="chip-row">
            {product.features.map(feature => (
              <span key={feature} className="chip">{feature}</span>
            ))}
          </div>
        </article>

        <article className="panel">
          <h3>匯入紀錄</h3>
          <div className="mini-list">
            {product.imports.length === 0 ? (
              <p className="muted">尚無匯入紀錄</p>
            ) : (
              product.imports.map(item => (
                <div key={item.id} className="mini-item">
                  <strong>{item.fileName}</strong>
                  <span>
                    {formatDateTime(item.createdAt)} ・ 成功 {item.successCount} / 失敗 {item.failureCount}
                  </span>
                </div>
              ))
            )}
          </div>
        </article>
      </section>

      <section className="panel">
        <div className="panel-head">
          <div>
            <h3>履歷時間軸</h3>
            <p>只保留你要的欄位：測試日期、測試名稱、測試內容</p>
          </div>
        </div>
        <div className="timeline-list">
          {sortedRecords.length === 0 ? (
            <p className="muted">尚無測試紀錄</p>
          ) : (
            sortedRecords.map(record => (
              <div key={record.id} className="timeline-item detail-timeline">
                <div className="timeline-date">{formatDateTime(record.testDate)}</div>
                <div>
                  <strong>{record.metricName}</strong>
                  <p>
                    {record.value} {record.unit}
                  </p>
                </div>
                <span className={`status-badge ${record.status}`}>{record.status}</span>
              </div>
            ))
          )}
        </div>
      </section>

      <section className="panel">
        <div className="panel-head">
          <div>
            <h3>測試項目分組</h3>
            <p>先看每個測試項目的最近五筆資料</p>
          </div>
        </div>
        <div className="metric-grid">
          {groupedByMetric.map(metric => (
            <article key={metric.id} className="metric-card">
              <div className="metric-card-head">
                <strong>{metric.name}</strong>
                <span>{metric.unit}</span>
              </div>
              <div className="mini-list">
                {metric.records.length === 0 ? (
                  <span className="muted">尚無資料</span>
                ) : (
                  metric.records.map(record => (
                    <div key={record.id} className="mini-item">
                      <strong>
                        {record.value} {record.unit}
                      </strong>
                      <span>{formatDate(record.testDate)}</span>
                    </div>
                  ))
                )}
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
