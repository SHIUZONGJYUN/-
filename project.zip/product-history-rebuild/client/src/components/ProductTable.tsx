import { Link } from "wouter";
import type { Product } from "../lib/types";
import { formatDate } from "../lib/format";

interface ProductTableProps {
  products: Product[];
}

export function ProductTable({ products }: ProductTableProps) {
  return (
    <div className="panel table-panel">
      <div className="panel-head">
        <div>
          <h2>履歷列表</h2>
          <p>首頁顯示最近三筆：測試日期、測試名稱、測試內容</p>
        </div>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>品項名稱</th>
              <th>產品料號</th>
              <th>AC/DC</th>
              <th>Tool Type</th>
              <th>建立時間</th>
              <th>末測日期</th>
              <th>履歷摘要</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id}>
                <td>{product.name}</td>
                <td>{product.partNumber}</td>
                <td>{product.category === "electric" ? "DC" : "AC / Air"}</td>
                <td>{product.toolType || "-"}</td>
                <td>{formatDate(product.createdAt)}</td>
                <td>{product.lastTestDate ? formatDate(product.lastTestDate) : "尚未測試"}</td>
                <td>
                  <div className="summary-list">
                    {(product.summary || []).length === 0 ? (
                      <span className="muted">尚無紀錄</span>
                    ) : (
                      (product.summary || []).map((item, index) => (
                        <div key={index} className="summary-item">
                          <span>{formatDate(item.testDate)}</span>
                          <strong>{item.metricName}</strong>
                          <span>
                            {item.value} {item.unit}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </td>
                <td>
                  <Link href={`/products/${product.id}`} className="text-link">
                    查看
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
