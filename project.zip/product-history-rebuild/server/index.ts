import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { commitImport, createProduct, dashboardSummary, getAllProducts, getProductById, updateProduct } from "./store";
import { parseImportFile } from "./importService";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 8787);

app.use(express.json({ limit: "15mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.get("/api/dashboard", (_req, res) => {
  res.json(dashboardSummary());
});

app.get("/api/products", (_req, res) => {
  const products = getAllProducts().map(product => ({
    ...product,
    lastTestDate:
      product.records.length > 0
        ? [...product.records].sort((a, b) => b.testDate.localeCompare(a.testDate))[0]?.testDate
        : null,
    summary: [...product.records]
      .sort((a, b) => b.testDate.localeCompare(a.testDate))
      .slice(0, 3)
      .map(item => ({
        testDate: item.testDate,
        metricName: item.metricName,
        value: item.value,
        unit: item.unit,
      })),
  }));
  res.json(products);
});

app.get("/api/products/:id", (req, res) => {
  const product = getProductById(Number(req.params.id));
  if (!product) {
    res.status(404).json({ message: "找不到產品" });
    return;
  }
  res.json(product);
});

app.post("/api/products", (req, res) => {
  const body = req.body;
  if (!body?.name || !body?.partNumber || !body?.category) {
    res.status(400).json({ message: "缺少必要欄位" });
    return;
  }
  const product = createProduct({
    name: body.name,
    partNumber: body.partNumber,
    category: body.category,
    supplier: body.supplier,
    toolType: body.toolType,
    description: body.description,
    features: Array.isArray(body.features) ? body.features : [],
  });
  res.status(201).json(product);
});

app.put("/api/products/:id", (req, res) => {
  const product = updateProduct(Number(req.params.id), req.body ?? {});
  if (!product) {
    res.status(404).json({ message: "找不到產品" });
    return;
  }
  res.json(product);
});

app.post("/api/import/preview", async (req, res) => {
  try {
    const { fileName, base64 } = req.body ?? {};
    if (!fileName || !base64) {
      res.status(400).json({ message: "請提供檔名與檔案內容" });
      return;
    }
    const rows = await parseImportFile(fileName, base64);
    res.json({
      fileName,
      rows,
      rowCount: rows.length,
      detectedMetrics: Array.from(new Set(rows.map(item => item.metricName).filter(Boolean))),
    });
  } catch (error) {
    res.status(400).json({
      message: error instanceof Error ? error.message : "解析失敗",
    });
  }
});

app.post("/api/import/commit", (req, res) => {
  try {
    const { productId, fileName, rows } = req.body ?? {};
    if (!productId || !fileName || !Array.isArray(rows)) {
      res.status(400).json({ message: "缺少必要欄位" });
      return;
    }
    const result = commitImport(Number(productId), fileName, rows);
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(400).json({
      message: error instanceof Error ? error.message : "寫入失敗",
    });
  }
});

if (process.env.NODE_ENV === "production") {
  const distPath = path.resolve(__dirname, "../dist");
  app.use(express.static(distPath));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

app.listen(port, () => {
  console.log(`Product History Rebuild server listening on http://localhost:${port}`);
});
