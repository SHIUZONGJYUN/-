import { FormEvent, useEffect, useMemo, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { api } from "../lib/api";
import type { Product } from "../lib/types";

const emptyForm = {
  name: "",
  partNumber: "",
  supplier: "M7",
  category: "electric",
  toolType: "",
  description: "",
  features: "",
};

export function ProductFormPage() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/products/:id/edit");
  const productId = useMemo(() => (match ? Number(params?.id) : null), [match, params]);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!productId) return;
    api
      .getProduct(productId)
      .then(product => {
        setForm({
          name: product.name,
          partNumber: product.partNumber,
          supplier: product.supplier || "",
          category: product.category,
          toolType: product.toolType || "",
          description: product.description || "",
          features: product.features.join("、"),
        });
      })
      .catch(err => setError(err.message));
  }, [productId]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");

    const payload: Partial<Product> = {
      name: form.name,
      partNumber: form.partNumber,
      supplier: form.supplier,
      category: form.category as Product["category"],
      toolType: form.toolType,
      description: form.description,
      features: form.features
        .split(/[、,]/)
        .map(item => item.trim())
        .filter(Boolean),
    };

    try {
      if (productId) {
        const product = await api.updateProduct(productId, payload);
        navigate(`/products/${product.id}`);
      } else {
        const product = await api.createProduct(payload);
        navigate(`/products/${product.id}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "儲存失敗");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="page-stack">
      <section className="page-header">
        <div>
          <p className="eyebrow">Product Setup</p>
          <h2>{productId ? "編輯品項" : "新增品項"}</h2>
          <p>先把產品主檔建立完整，後面的測試匯入與履歷才會穩定。</p>
        </div>
      </section>

      <form className="panel form-grid" onSubmit={handleSubmit}>
        <label>
          品項名稱
          <input value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} required />
        </label>
        <label>
          產品料號
          <input value={form.partNumber} onChange={event => setForm({ ...form, partNumber: event.target.value })} required />
        </label>
        <label>
          供應商
          <input value={form.supplier} onChange={event => setForm({ ...form, supplier: event.target.value })} />
        </label>
        <label>
          類別
          <select value={form.category} onChange={event => setForm({ ...form, category: event.target.value })}>
            <option value="electric">電動</option>
            <option value="pneumatic">氣動</option>
          </select>
        </label>
        <label>
          Tool Type
          <input value={form.toolType} onChange={event => setForm({ ...form, toolType: event.target.value })} />
        </label>
        <label className="full-span">
          產品特色
          <input
            value={form.features}
            onChange={event => setForm({ ...form, features: event.target.value })}
            placeholder="以 、 或 , 分隔"
          />
        </label>
        <label className="full-span">
          產品描述
          <textarea value={form.description} onChange={event => setForm({ ...form, description: event.target.value })} rows={5} />
        </label>

        {error ? <div className="inline-error full-span">{error}</div> : null}

        <div className="form-actions full-span">
          <button type="submit" className="primary-button" disabled={saving}>
            {saving ? "儲存中..." : "儲存品項"}
          </button>
        </div>
      </form>
    </div>
  );
}
