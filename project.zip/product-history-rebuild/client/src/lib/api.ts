import type { DashboardResponse, ParsedImportRecord, Product } from "./types";

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
    },
    ...init,
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message || "請求失敗");
  }

  return response.json() as Promise<T>;
}

export const api = {
  getDashboard() {
    return request<DashboardResponse>("/api/dashboard");
  },
  getProducts() {
    return request<Product[]>("/api/products");
  },
  getProduct(id: number) {
    return request<Product>(`/api/products/${id}`);
  },
  createProduct(payload: Partial<Product>) {
    return request<Product>("/api/products", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },
  updateProduct(id: number, payload: Partial<Product>) {
    return request<Product>(`/api/products/${id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
  },
  previewImport(fileName: string, base64: string) {
    return request<{
      fileName: string;
      rows: ParsedImportRecord[];
      rowCount: number;
      detectedMetrics: string[];
    }>("/api/import/preview", {
      method: "POST",
      body: JSON.stringify({ fileName, base64 }),
    });
  },
  commitImport(productId: number, fileName: string, rows: ParsedImportRecord[]) {
    return request<{ success: true; inserted: number; ignored: number }>("/api/import/commit", {
      method: "POST",
      body: JSON.stringify({ productId, fileName, rows }),
    });
  },
};
